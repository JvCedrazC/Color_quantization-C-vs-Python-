# Conferência das cinco implementações

Todas recebem a mesma imagem PPM P6 por argumento e são chamadas com quatro cores por `run_all.sh`. O algoritmo-base é quantização por octree, sem dithering nos testes. O código Python serial é um port do C serial; as versões paralelas preservam as etapas de construção da octree, redução de folhas e substituição de cores, mas usam histogramas/árvores locais e combinação serial para permitir a divisão do trabalho. A ordem de inserção e dos empates no heap pode diferir; portanto, a equivalência exata da imagem de saída ainda exige comparação de saídas, não apenas dos tempos.

| Versão | Conferência com o enunciado |
| --- | --- |
| C serial | Sem OpenMP; tempo interno com `clock_gettime`; compilação `-O2 -g`. Na rodada anterior com `potm2608a.ppm`, a quantização interna mediu 27,52–28,34 s com `-O2`, acima de 20 s naquele ambiente. É necessário repetir a medição wall-clock após as alterações para comprovar o requisito final. |
| C OpenMP | Usa `#pragma omp parallel`, `omp for` e `parallel for`; `OMP_NUM_THREADS` seleciona 1/2/4/8. A soma das árvores locais usa `critical`, não `reduction`, pois a estrutura da octree não admite redução escalar direta. Mede tempo interno e, quando o runner fornece a referência serial, imprime speedup e eficiência. |
| Python serial | Usa estruturas da biblioteca padrão, sem NumPy ou bibliotecas externas, e `perf_counter`. |
| Python multithreading | Divide a contagem e a substituição em faixas e usa diretamente `threading.Thread` com 1/2/4/8 threads. No CPython, essas tarefas CPU-bound competem pelo GIL; mais threads não implicam mais núcleos executando bytecode simultaneamente. |
| Python multiprocessing | Usa `ProcessPoolExecutor`, aceita somente 1/2/4/8 processos e mede com `perf_counter`. Cada processo tem seu próprio interpretador/GIL, mas recebe blocos via pickle e pode duplicar memória. |

`/usr/bin/time -v` mede o processo completo (leitura, quantização e escrita); os tempos internos medem apenas a quantização. O runner guarda ambos separadamente. Speedup e eficiência de wall-clock são calculados depois de medir os seriais. O CSV `summary.csv` contém o speedup do tempo interno, e `wall_summary.csv`, o de processo completo.

Os perfis (`gprof`, Callgrind, Cachegrind, `strace`, `perf` e `cProfile`) são execuções adicionais, fora das médias. O `perf` pode falhar por falta de permissão do kernel; nesse caso, a ausência de contadores não deve ser interpretada como zero. Callgrind/Cachegrind podem usar `PROFILE_INPUT` menor; comparações numéricas só são válidas entre medições com a mesma entrada. O RSS de `/usr/bin/time -v` no multiprocessing não é a soma do RSS de todos os processos.

Ainda não há perfis novos nem números de speedup verificados após estes ajustes: o benchmark não foi executado nesta alteração. Os relatórios gerados pela próxima rodada devem fundamentar a identificação de hotspots, IPC, cache misses, syscalls e o efeito observado do GIL. A fração paralelizável `p` da Lei de Amdahl não foi medida; o limite teórico é `S(N) <= 1 / ((1-p) + p/N)`.
