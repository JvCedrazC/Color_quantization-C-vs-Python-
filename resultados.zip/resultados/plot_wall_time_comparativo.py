#!/usr/bin/env python3
"""Compara o wall-clock medio das cinco versoes em um unico grafico."""

import argparse
import csv
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Patch


DEFAULT_CSV = Path(__file__).resolve().parent / "resumos/run-Zz7rg9Ye/wall_summary.csv"
WORKERS = (1, 2, 4, 8)
CASES = (
    ("c_serial", 1, "C serial", "tab:blue"),
    *(("c_parallel", n, f"C OpenMP · {n} thread(s)", "tab:cyan") for n in WORKERS),
    ("py_serial", 1, "Python serial", "tab:purple"),
    *(("py_multithreading", n, f"Python threads · {n}", "tab:orange") for n in WORKERS),
    *(("py_multiprocessing", n, f"Python processos · {n}", "tab:green") for n in WORKERS),
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", nargs="?", type=Path, default=DEFAULT_CSV)
    parser.add_argument("--saida", type=Path,
                        help="PNG de saida; padrao: wall_time_comparativo.png ao lado do CSV")
    args = parser.parse_args()

    times = {}
    with args.csv.open(newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            key = (row["versao"], int(row["workers"]))
            if key in times:
                raise ValueError(f"Configuracao duplicada: {key}")
            times[key] = float(row["wall_medio_s"])
    if any(value <= 0 for value in times.values()):
        raise ValueError("Todos os tempos devem ser positivos para a escala logaritmica")

    fig, ax = plt.subplots(figsize=(11, 8))
    labels = []
    values = []
    colors = []
    print("versao,workers,wall_medio_s")
    for version, workers, label, color in CASES:
        value = times[(version, workers)]
        print(f"{version},{workers},{value:.6f}")
        labels.append(label)
        values.append(value)
        colors.append(color)

    positions = range(len(CASES))
    ax.barh(positions, values, color=colors, height=0.72)
    for position, value in zip(positions, values):
        ax.text(value * 1.06, position, f"{value:.2f} s", va="center", fontsize=9)
    ax.set_yticks(list(positions), labels)
    ax.invert_yaxis()
    ax.set_xscale("log")
    ax.set_xlim(1, 390)
    ticks = [1, 2, 5, 10, 20, 50, 100, 200]
    ax.set_xticks(ticks, [str(tick) for tick in ticks])
    ax.set_xlabel("Wall-clock medio (segundos; escala logaritmica)")
    ax.set_title("Tempo de execucao por versao e numero de workers")
    ax.grid(axis="x", alpha=0.25, which="both")
    ax.set_axisbelow(True)
    for boundary in (4.5, 5.5, 9.5):
        ax.axhline(boundary, color="gray", linewidth=0.8, alpha=0.4)
    ax.legend(handles=[
        Patch(color="tab:blue", label="C serial"),
        Patch(color="tab:cyan", label="C OpenMP"),
        Patch(color="tab:purple", label="Python serial"),
        Patch(color="tab:orange", label="Python multithreading"),
        Patch(color="tab:green", label="Python multiprocessing"),
    ], loc="lower right", fontsize=8)
    fig.tight_layout()

    output = args.saida or args.csv.with_name("wall_time_comparativo.png")
    fig.savefig(output, dpi=180)
    plt.close(fig)
    print(f"Grafico salvo em: {output}")


if __name__ == "__main__":
    main()
