#!/usr/bin/env python3
"""Plota o pico de RSS em cinco paineis comparativos."""

import argparse
import csv
from pathlib import Path

import matplotlib.pyplot as plt


DEFAULT_CSV = Path(__file__).resolve().parent / "resumos/run-Zz7rg9Ye/wall_summary.csv"
VERSIONS = (
    ("c_serial", "C serial", "tab:blue"),
    ("c_parallel", "C OpenMP", "tab:cyan"),
    ("py_serial", "Python serial", "tab:purple"),
    ("py_multithreading", "Python multithreading", "tab:orange"),
    ("py_multiprocessing", "Python multiprocessing", "tab:green"),
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", nargs="?", type=Path, default=DEFAULT_CSV)
    parser.add_argument("--saida", type=Path,
                        help="PNG de saida; padrao: memoria_comparativo.png ao lado do CSV")
    args = parser.parse_args()

    rss = {}
    with args.csv.open(newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            key = (row["versao"], int(row["workers"]))
            if key in rss:
                raise ValueError(f"Configuracao duplicada: {key}")
            rss[key] = float(row["rss_max_kb"]) / 1024

    fig, axes = plt.subplots(2, 3, figsize=(17, 9), sharey=True)
    print("versao,workers,pico_rss_mib")
    for ax, (version, title, color) in zip(axes.flat, VERSIONS):
        workers = sorted(n for name, n in rss if name == version)
        if not workers:
            raise ValueError(f"Versao ausente no CSV: {version}")
        values = [rss[(version, n)] for n in workers]
        if any(value <= 0 for value in values):
            raise ValueError(f"RSS invalido para {version}")
        positions = list(range(len(workers)))
        bars = ax.bar(positions, values, width=0.6, color=color)
        for bar, n, value in zip(bars, workers, values):
            print(f"{version},{n},{value:.1f}")
            ax.text(bar.get_x() + bar.get_width() / 2, value + 35,
                    f"{value:.0f}", ha="center", va="bottom", fontsize=8)
        ax.set_xticks(positions, [str(n) for n in workers])
        ax.set_ylim(0, 2700)
        ax.set_xlabel("Workers")
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.25)
        ax.set_axisbelow(True)

    axes[1, 2].axis("off")
    fig.suptitle("Pico de memoria residente por versao e numero de workers")
    fig.supylabel("RSS maximo (MiB)")
    fig.text(0.5, 0.015,
             "Multiprocessing: RSS do processo medido; nao representa a soma dos workers.",
             ha="center", fontsize=9)
    fig.tight_layout(rect=(0.03, 0.04, 1, 0.95))

    output = args.saida or args.csv.with_name("memoria_comparativo.png")
    fig.savefig(output, dpi=180)
    plt.close(fig)
    print(f"Grafico salvo em: {output}")


if __name__ == "__main__":
    main()
