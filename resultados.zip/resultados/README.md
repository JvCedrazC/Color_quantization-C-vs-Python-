# Resultados dos benchmarks

Cada pasta `run-*` corresponde a uma execução do `run_all.sh`. A organização é:

```text
resultados/
├── C_results/
│   ├── serial/run-*/
│   └── paralelo/run-*/
├── python_results/
│   ├── serial/run-*/
│   ├── multithreading/run-*/
│   └── multiprocessing/run-*/
└── resumos/run-*/
```

Em cada versão, `logs/` guarda as saídas, `timev/` guarda as medições `/usr/bin/time -v`, e `profiles/` guarda os perfis. A pasta `resumos/run-*` guarda os CSVs globais e `comparacao.md` da rodada.

Arquivos gerados:

- `summary.csv`: tempo interno médio de quantização, aceleração, speedup e eficiência por configuração (em `resumos/run-*`).
- `times.csv`: tempo de cada repetição (em `resumos/run-*`).
- `metrics.csv`: métricas individuais de `/usr/bin/time -v`.
- `wall_summary.csv`: médias e speedup de wall-clock, com dados de CPU, memória, falhas de página e trocas de contexto.
- `comparacao.md`: comparação das cinco versões (paralelas com 4 trabalhadores).
- `logs/`: saída dos programas e dos testes de perfilamento.
- `profiles/`: resultados de `perf`, gprof, Callgrind, Cachegrind, `strace` e `cProfile`.
- `bin/`: executáveis C compilados para aquela rodada.

Identificação das versões nos nomes dos arquivos e no CSV:

| Identificador | Programa |
| --- | --- |
| `c_serial_1` | C serial, compilado com `-O2` |
| `c_parallel_1`, `_2`, `_4`, `_8` | C paralelo com 1, 2, 4 ou 8 threads OpenMP |
| `py_multithreading_1`, `_2`, `_4`, `_8` | Python multithreading com 1, 2, 4 ou 8 threads |
| `py_multiprocessing_1`, `_2`, `_4`, `_8` | Python multiprocessing com 1, 2, 4 ou 8 processos |
| `py_serial_1` | Python serial |

Os nomes `*_time_1.log`, `*_time_2.log` e `*_time_3.log` indicam a repetição. Os arquivos `timev/*.timev.txt` guardam `/usr/bin/time -v`. O script mede nesta ordem: C serial (3 vezes), C OpenMP 1/2/4/8 (3 vezes cada), Python serial (1 vez), Python multiprocessing 1/2/4/8 (3 vezes cada), Python multithreading 1/2/4/8 (3 vezes cada). Só então faz profiling C e profiling Python, uma vez por ferramenta e configuração. Os perfis são execuções extras, separadas dos tempos usados na média. Para profiling reduzido, defina `PROFILE_INPUT` ao executar `run_all.sh`.
