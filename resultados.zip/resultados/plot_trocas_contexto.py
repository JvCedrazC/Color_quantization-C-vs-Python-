#!/usr/bin/env python3
"""Gera um grafico comparativo com cinco paineis de trocas de contexto."""

import argparse
import csv
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Patch


DEFAULT_CSV = Path(__file__).resolve().parent / "resumos/run-Zz7rg9Ye/wall_summary.csv"
VERSIONS = (
    ("c_serial", "C serial"),
    ("c_parallel", "C OpenMP"),
    ("py_serial", "Python serial"),
    ("py_multithreading", "Python multithreading"),
    ("py_multiprocessing", "Python multiprocessing (processo principal)"),
)


def label_number(value):
    return f"{value:,.0f}".replace(",", ".")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", nargs="?", type=Path, default=DEFAULT_CSV)
    parser.add_argument("--saida", type=Path,
                        help="PNG de saida; padrao: trocas_contexto_comparativo.png ao lado do CSV")
    args = parser.parse_args()

    rows = {}
    with args.csv.open(newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            key = (row["versao"], int(row["workers"]))
            if key in rows:
                raise ValueError(f"Configuracao duplicada: {key}")
            rows[key] = (
                float(row["voluntary_switches_medio"]),
                float(row["involuntary_switches_medio"]),
            )

    fig, axes = plt.subplots(2, 3, figsize=(17, 9), sharey=True)
    for ax, (version, title) in zip(axes.flat, VERSIONS):
        workers = sorted(n for name, n in rows if name == version)
        if not workers:
            raise ValueError(f"Versao ausente no CSV: {version}")
        voluntary = [rows[(version, n)][0] for n in workers]
        involuntary = [rows[(version, n)][1] for n in workers]
        if any(value <= 0 for value in voluntary + involuntary):
            raise ValueError(f"A escala logaritmica requer valores positivos: {version}")

        positions = list(range(len(workers)))
        width = 0.35
        bars_vol = ax.bar([x - width / 2 for x in positions], voluntary,
                          width=width, color="tab:blue", label="Voluntarias")
        bars_invol = ax.bar([x + width / 2 for x in positions], involuntary,
                            width=width, color="tab:orange", label="Involuntarias")
        for bar, value in zip((*bars_vol, *bars_invol), (*voluntary, *involuntary)):
            ax.text(bar.get_x() + bar.get_width() / 2, value * 1.06,
                    label_number(value), ha="center", va="bottom", fontsize=8)

        ax.set_yscale("log")
        ax.set_ylim(0.8, 250000)
        ax.set_xticks(positions, [str(n) for n in workers])
        ax.set_xlabel("Workers")
        ax.set_title(title)
        ax.grid(axis="y", which="both", alpha=0.2)
        ax.set_axisbelow(True)

    axes[1, 2].axis("off")
    axes[1, 2].legend(handles=[
        Patch(color="tab:blue", label="Voluntarias"),
        Patch(color="tab:orange", label="Involuntarias"),
    ], loc="center", fontsize=12)
    fig.suptitle("Trocas de contexto por versao e numero de workers")
    fig.supylabel("Media de trocas (escala logaritmica)")
    fig.text(0.5, 0.015, "Multiprocessing: medicao do processo coordenador; nao soma os workers.",
             ha="center", fontsize=10)
    fig.tight_layout(rect=(0.03, 0.04, 1, 0.95))
    output = args.saida or args.csv.with_name("trocas_contexto_comparativo.png")
    fig.savefig(output, dpi=180)
    plt.close(fig)
    print(f"Grafico salvo em: {output}")


if __name__ == "__main__":
    main()
