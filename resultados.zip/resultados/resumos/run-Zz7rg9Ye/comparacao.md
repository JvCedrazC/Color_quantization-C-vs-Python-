# Comparação das cinco versões

Medidas de processo completo com `/usr/bin/time -v`. Speedup relativo ao serial da mesma linguagem.

| Versão | Wall (s) | User (s) | System (s) | CPU % | RSS máx. (KB) | Major/minor faults | Trocas vol./invol. | Speedup | Eficiência |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| C serial | 6.773333 | 6.613333 | 0.156667 | 99.33 | 514396 | 0.00/128260.67 | 1.00/60.00 | 1.0000 | 1.0000 |
| C OpenMP | 2.786667 | 10.060000 | 0.196667 | 367.33 | 587528 | 0.00/150143.33 | 79.00/175.33 | 2.4306 | 0.6077 |
| Python serial | 260.830000 | 260.290000 | 0.450000 | 99.00 | 985504 | 0.00/265495.00 | 1.00/4796.00 | 1.0000 | 1.0000 |
| Python threading | 85.786667 | 86.123333 | 0.703333 | 101.00 | 985648 | 0.00/371050.00 | 78403.00/756.00 | 3.0404 | 0.7601 |
| Python multiprocessing | 28.623333 | 4.623333 | 1.753333 | 22.00 | 2428532 | 0.00/1592312.67 | 15412.00/95.33 | 9.1125 | 2.2781 |

As cinco versões executam quantização CPU-bound. Threads Python podem esperar pelo GIL; processos podem esperar por IPC/pickle, não necessariamente por I/O.
No multiprocessing, cada worker tem interpretador e GIL próprios. Compare no cProfile o custo de iniciar processos e de serializar/deserializar blocos (pickle), e compare o wall-clock e RSS com threading.
O RSS de `/usr/bin/time -v` para multiprocessing não é a soma da memória de todos os processos: os dados e o interpretador podem ocupar memória em cada worker.
A Lei de Amdahl é S(N) ≤ 1/((1-p)+p/N); sem estimar p, não há limite teórico numérico confiável.
