#!/usr/bin/env python3
"""Speedup do Python multithreading: absoluto e relativo."""

import argparse
import csv
from pathlib import Path

import matplotlib.pyplot as plt


DEFAULT_CSV = Path(__file__).resolve().parent / "resumos/run-Zz7rg9Ye/wall_summary.csv"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", nargs="?", type=Path, default=DEFAULT_CSV)
    parser.add_argument("--saida", type=Path)
    args = parser.parse_args()

    times = {}
    with args.csv.open(newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            if row["versao"] in {"py_serial", "py_multithreading"}:
                times[(row["versao"], int(row["workers"]))] = float(row["wall_medio_s"])

    serial = times[("py_serial", 1)]
    workers = (1, 2, 4, 8)
    measured = [times[("py_multithreading", n)] for n in workers]
    if serial <= 0 or any(t <= 0 for t in measured):
        raise ValueError("Todos os tempos devem ser positivos")
    absolute = [serial / t for t in measured]
    relative = [1.0] + [measured[i - 1] / measured[i] for i in range(1, 4)]

    print("threads,wall_medio_s,speedup_absoluto,speedup_relativo")
    for n, t, a, r in zip(workers, measured, absolute, relative):
        print(f"{n},{t:.6f},{a:.4f},{r:.4f}")

    positions = range(len(workers))
    fig, ax = plt.subplots(figsize=(9, 6))
    ax.plot(positions, absolute, color="tab:blue", marker="o", label="Absoluto / Python serial")
    ax.plot(positions, relative, color="tab:orange", marker="s", linestyle="--",
            label="Relativo / threads anteriores")
    for position, value in zip(positions, absolute):
        ax.annotate(f"{value:.2f}×", (position, value), xytext=(0, -18),
                        textcoords="offset points", ha="center", color="tab:blue")
    for position, value in zip(positions, relative):
        ax.annotate(f"{value:.2f}×", (position, value), xytext=(0, 10),
                        textcoords="offset points", ha="center", color="tab:orange")
    ax.set(xlabel="Threads", ylabel="Speedup (vezes)", title="Python multithreading")
    ax.set_xticks(list(positions), [str(n) for n in workers])
    ax.set_xlim(-0.25, 3.25)
    ax.set_ylim(0, 4)
    ax.set_yticks([i / 2 for i in range(9)])
    ax.grid(alpha=0.25)
    ax.legend(loc="upper left")
    fig.tight_layout()
    output = args.saida or args.csv.with_name("speedup_multithreading.png")
    fig.savefig(output, dpi=180)
    plt.close(fig)
    print(f"Grafico salvo em: {output}")


if __name__ == "__main__":
    main()
