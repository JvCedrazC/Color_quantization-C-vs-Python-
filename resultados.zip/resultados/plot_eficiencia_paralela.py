#!/usr/bin/env python3
"""Plota a eficiencia paralela relativa a 1 worker de cada implementacao.

E(n) = T(1) / (n * T(n)). O baseline de 1 worker evita confundir a
otimizacao do histograma Python com o ganho obtido ao adicionar workers.
"""

import argparse
import csv
from pathlib import Path

import matplotlib.pyplot as plt


DEFAULT_CSV = Path(__file__).resolve().parent / "resumos/run-Zz7rg9Ye/wall_summary.csv"
VERSIONS = (
    ("c_parallel", "C OpenMP", "tab:blue"),
    ("py_multithreading", "Python multithreading", "tab:orange"),
    ("py_multiprocessing", "Python multiprocessing", "tab:green"),
)
WORKERS = (1, 2, 4, 8)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", nargs="?", type=Path, default=DEFAULT_CSV,
                        help="CSV com wall_medio_s de cada versao")
    parser.add_argument("--saida", type=Path,
                        help="PNG de saida; padrao: eficiencia_paralela.png ao lado do CSV")
    args = parser.parse_args()

    times = {}
    with args.csv.open(newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            key = (row["versao"], int(row["workers"]))
            if key in times:
                raise ValueError(f"Configuracao duplicada: {key}")
            times[key] = float(row["wall_medio_s"])

    fig, ax = plt.subplots(figsize=(10, 6))
    positions = range(len(WORKERS))
    print("versao,workers,wall_medio_s,eficiencia_pct")

    for version, label, color in VERSIONS:
        measured = [times[(version, n)] for n in WORKERS]
        if any(t <= 0 for t in measured):
            raise ValueError(f"Tempos invalidos para {version}")
        efficiency = [100 * measured[0] / (n * t)
                      for n, t in zip(WORKERS, measured)]
        ax.plot(positions, efficiency, marker="o", linewidth=2, color=color, label=label)
        for position, n, t, value in zip(positions, WORKERS, measured, efficiency):
            print(f"{version},{n},{t:.6f},{value:.2f}")
            if n == 1:
                continue  # As tres curvas comecam em 100%; rotular uma unica vez.
            offset = -17 if version == "c_parallel" and n == 2 else 9
            ax.annotate(f"{value:.1f}%", (position, value), xytext=(0, offset),
                        textcoords="offset points", ha="center", color=color)

    ax.annotate("100%", (0, 100), xytext=(0, 10),
                textcoords="offset points", ha="center")
    ax.set_xticks(list(positions), [str(n) for n in WORKERS])
    ax.set_xlim(-0.25, 3.25)
    ax.set_ylim(0, 110)
    ax.set_yticks(range(0, 101, 10))
    ax.set_xlabel("Threads ou processos")
    ax.set_ylabel("Eficiência paralela (%)")
    ax.set_title("Eficiência relativa a 1 worker da própria implementação")
    ax.grid(alpha=0.25)
    ax.legend(loc="lower left")
    fig.tight_layout()

    output = args.saida or args.csv.with_name("eficiencia_paralela.png")
    fig.savefig(output, dpi=180)
    plt.close(fig)
    print(f"Grafico salvo em: {output}")


if __name__ == "__main__":
    main()
